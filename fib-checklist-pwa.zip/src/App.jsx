import React, { useEffect, useState } from 'react';

const CHECKLIST_ITEMS = [
  { id: 'ms_trend', label: 'Confirm trend on 15m / 5m / 1m' },
  { id: 'emas', label: '20EMA & 50EMA aligned with trend' },
  { id: 'sr_zones', label: 'Major Support / Resistance zones marked' },
  { id: 'fib_draw', label: 'Fib drawn (swing high↔low)' },
  { id: 'fib_levels', label: 'Key Fib levels marked: 38.2%, 50%, 61.8%' },
  { id: 'vwap', label: 'VWAP confluence (Price above/below VWAP)' },
  { id: 'emas_fast', label: '9/15/20 EMAs relation to 50 EMA' },
  { id: 'rsi', label: 'RSI conditions & no divergence' },
  { id: 'pa_confirm', label: 'Price action confirmation (engulf/pin/hammer)' },
  { id: 'volume', label: 'Volume spike / clear rejection present' },
  { id: 'risk_rr', label: 'Risk & RR calculated, SL/TP set (1:2 target)' },
  { id: 'exec_rules', label: 'All confluences align before entry' },
  { id: 'adx', label: 'ADX >20 and +DI/-DI confirm trend' },
  { id: 'live_manage', label: 'Live management rules applied (news, SL->BE)' },
  { id: 'journal', label: 'Journaling: record levels, indicators, lessons' }
];

const STORAGE_KEY = 'fib_checklist_history_v1';

function formatDateKey(date) {
  const d = new Date(date);
  return d.toISOString().slice(0, 10);
}

function emptyEntryForDate(dateKey) {
  const items = {};
  CHECKLIST_ITEMS.forEach((it) => {
    items[it.id] = { checked: false, note: '' };
  });
  return { date: dateKey, items, savedAt: new Date().toISOString() };
}

export default function App(){
  const todayKey = formatDateKey(new Date());
  const [dateKey, setDateKey] = useState(todayKey);
  const [entry, setEntry] = useState(() => emptyEntryForDate(todayKey));
  const [historyKeys, setHistoryKeys] = useState([]);

  useEffect(() => { loadHistoryKeys(); }, []);
  useEffect(() => { loadEntryForDate(dateKey); }, [dateKey]);

  function loadHistoryKeys(){
    const raw = localStorage.getItem(STORAGE_KEY);
    if(!raw) return setHistoryKeys([]);
    try{
      const parsed = JSON.parse(raw);
      const keys = Object.keys(parsed).sort((a,b)=> b.localeCompare(a));
      setHistoryKeys(keys);
    }catch(e){ console.error(e); setHistoryKeys([]); }
  }

  function loadEntryForDate(key){
    const raw = localStorage.getItem(STORAGE_KEY);
    if(!raw) return setEntry(emptyEntryForDate(key));
    try{
      const parsed = JSON.parse(raw);
      if(parsed[key]) setEntry(parsed[key]);
      else setEntry(emptyEntryForDate(key));
    }catch(e){ console.error(e); setEntry(emptyEntryForDate(key)); }
  }

  function saveEntry(){
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    const toSave = { ...parsed, [entry.date]: { ...entry, savedAt: new Date().toISOString() } };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(toSave));
    loadHistoryKeys();
    alert('Saved ✅');
  }

  function updateChecked(itemId, checked){
    setEntry(prev => ({ ...prev, items: { ...prev.items, [itemId]: { ...prev.items[itemId], checked } } }));
  }
  function updateNote(itemId, note){
    setEntry(prev => ({ ...prev, items: { ...prev.items, [itemId]: { ...prev.items[itemId], note } } }));
  }

  function handleDateChange(e){
    const newKey = formatDateKey(e.target.value);
    setDateKey(newKey);
    setEntry(emptyEntryForDate(newKey));
  }

  function clearForDate(){
    if(!confirm('Clear checklist for this date?')) return;
    const newEntry = emptyEntryForDate(dateKey);
    setEntry(newEntry);
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    parsed[dateKey] = newEntry;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(parsed));
    loadHistoryKeys();
  }

  function deleteDate(key){
    if(!confirm(`Delete saved checklist for ${key}? This cannot be undone.`)) return;
    const raw = localStorage.getItem(STORAGE_KEY);
    if(!raw) return;
    const parsed = JSON.parse(raw);
    delete parsed[key];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(parsed));
    loadHistoryKeys();
    if(key === dateKey) setEntry(emptyEntryForDate(todayKey));
  }

  function exportCSV(single = true){
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    let rows = [];
    if(single){
      const e = parsed[dateKey] || entry;
      rows.push(['date','item_id','item_label','checked','note']);
      CHECKLIST_ITEMS.forEach((it)=>{
        const state = e.items[it.id] || { checked:false, note:'' };
        rows.push([e.date, it.id, it.label, state.checked ? '1':'0', `"${(state.note||'').replace(/"/g,'""')}"`]);
      });
    } else {
      rows.push(['date','item_id','item_label','checked','note']);
      Object.keys(parsed).sort().forEach((k)=>{
        const e = parsed[k];
        CHECKLIST_ITEMS.forEach((it)=>{
          const state = e.items[it.id] || { checked:false, note:'' };
          rows.push([e.date, it.id, it.label, state.checked ? '1':'0', `"${(state.note||'').replace(/"/g,'""')}"`]);
        });
      });
    }
    const csv = rows.map(r=> r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = single ? `fib_checklist_${dateKey}.csv` : `fib_checklist_full_history.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="app">
      <div className="card">
        <header>
          <div>
            <h1>Fibonacci Confluence Checklist</h1>
            <div className="small">Daily checklist, ADX + Fibonacci, save & export</div>
          </div>
          <div className="controls">
            <input type="date" value={dateKey} onChange={handleDateChange} />
            <button className="btn" onClick={saveEntry}>Save</button>
            <button className="btn secondary" onClick={()=>exportCSV(true)}>Export CSV</button>
            <button className="btn secondary" onClick={()=>exportCSV(false)}>Export All</button>
          </div>
        </header>

        <div className="list">
          {CHECKLIST_ITEMS.map((it)=> {
            const state = entry.items?.[it.id] || { checked:false, note:'' };
            return (
              <div className="item" key={it.id}>
                <div style={{width:240}}>
                  <label>
                    <input type="checkbox" checked={state.checked} onChange={(e)=> updateChecked(it.id, e.target.checked)} />
                    <strong style={{marginLeft:8}}>{it.label}</strong>
                  </label>
                </div>
                <textarea placeholder="Optional note (levels, why skipped, screenshot ref)" value={state.note} onChange={(e)=> updateNote(it.id, e.target.value)} rows={2} />
              </div>
            );
          })}
        </div>
      </div>

      <div className="card" style={{marginTop:12}}>
        <h3>History</h3>
        <div className="history">
          {historyKeys.length === 0 ? <div className="small">No saved records yet.</div> : historyKeys.map((k)=>(
            <div key={k} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'8px 0',borderBottom:'1px solid #eef2f7'}}>
              <div>
                <div style={{fontWeight:600}}>{k}</div>
                <div className="small">Saved</div>
              </div>
              <div style={{display:'flex',gap:8}}>
                <button className="btn secondary" onClick={()=>{ setDateKey(k); loadEntryForDate(k); }}>Load</button>
                <button className="btn" onClick={()=> deleteDate(k)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
        <div style={{marginTop:10}}>
          <button className="btn secondary" onClick={()=>{ const all = localStorage.getItem(STORAGE_KEY); alert(all || '{}'); }}>View Raw Storage</button>
          <button className="btn" style={{marginLeft:8,background:'#ef4444'}} onClick={()=>{ if(confirm('Delete all saved data?')){ localStorage.removeItem(STORAGE_KEY); loadHistoryKeys(); setEntry(emptyEntryForDate(todayKey)); } }}>Clear All</button>
        </div>
      </div>

    </div>
  );
}
